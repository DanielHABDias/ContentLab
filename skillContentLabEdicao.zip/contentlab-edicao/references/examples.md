# Exemplos de edit_plan.json

Os caminhos abaixo são exemplos. Em projeto real, use somente assets existentes.

## 1. Cena simples + texto

```json
{
  "id": "s01",
  "start": 0,
  "end": 6,
  "layout": "fullscreen",
  "elements": [
    {
      "type": "video",
      "asset": "project://assets/intro.mp4",
      "fit": "cover"
    },
    {
      "type": "text",
      "text": "NÃO MATA",
      "style": "impact",
      "start": 1.2,
      "end": 3.5,
      "z": 10
    }
  ],
  "transitionOut": "cut"
}
```

## 2. Frase palavra por palavra

```json
{
  "id": "s02",
  "start": 6,
  "end": 11,
  "layout": "fullscreen",
  "background": {"color": "#000000"},
  "elements": [
    {
      "type": "kinetic_text",
      "text": "ESSA REGRA TEM UM PREÇO",
      "style": "word_pop",
      "sync": "transcript",
      "emphasis": ["REGRA", "PREÇO"]
    }
  ],
  "transitionOut": "cut"
}
```

## 3. Três personagens

```json
{
  "id": "s03",
  "start": 11,
  "end": 18,
  "layout": "three_columns",
  "background": {
    "asset": "project://assets/grid_animado.mp4",
    "fit": "cover",
    "loop": true
  },
  "elements": [
    {
      "type": "image",
      "asset": "project://assets/a.png",
      "fit": "contain",
      "animation": {"enter": "slide_up", "idle": "float_soft", "exit": "cut"}
    },
    {
      "type": "image",
      "asset": "project://assets/b.png",
      "fit": "contain",
      "animation": {"enter": "slide_up", "idle": "float_soft", "exit": "cut"}
    },
    {
      "type": "image",
      "asset": "project://assets/c.png",
      "fit": "contain",
      "animation": {"enter": "slide_up", "idle": "float_soft", "exit": "cut"}
    }
  ],
  "transitionOut": "blur_left"
}
```

## 4. Card nos dois terços superiores

```json
{
  "id": "s04",
  "start": 18,
  "end": 25,
  "layout": "3x3",
  "background": {"color": "#111111"},
  "elements": [
    {
      "type": "image",
      "asset": "project://assets/comic.jpg",
      "cells": [1,2,3,4,5,6],
      "fit": "cover",
      "box": {
        "preset": "floating_card",
        "padding": 32,
        "radius": 30,
        "shadow": "soft"
      },
      "animation": {"enter": "fade", "idle": "slow_zoom_out", "exit": "cut"}
    }
  ],
  "transitionOut": "cut"
}
```

## 5. Overlay greenscreen

```json
{
  "type": "overlay",
  "asset": "project://assets/cta_green.mp4",
  "style": "green_screen_default",
  "start": 30,
  "end": 34,
  "cells": [7,8,9],
  "z": 20,
  "config": {
    "keyColor": "0x00FF00",
    "similarity": 0.18,
    "blend": 0.08
  }
}
```

## 6. Caption karaoke

```json
{
  "type": "caption",
  "style": "anton_karaoke",
  "range": {"start": 35, "end": 43},
  "cells": [7,8,9],
  "z": 30
}
```
