# Motion design — proposta Content Lab

Objetivo: cenas contínuas com fundo persistente, personagens/objetos PNG e palavras em camadas, revelados por uma câmera virtual. Exemplo: o personagem A aparece; a fala passa a outro personagem; a câmera se move para o Homem de Ferro no mesmo fundo, sem corte de plano.

## Estado e contrato

- Implementado: JSON `0.1`, camadas, textos, animações simples e cortes/transições.
- Planejado: JSON `0.2` com `scene.camera.keyframes`, `elements[].id`, `transform` e `keyframes`. Consulte `MOTION_DESIGN_PLAN.md` e `examples/motion-design-proposal.v0.2.json` do repositório quando disponíveis.
- **Não enviar `0.2` ao validador/renderizador atual.** Não declarar que o vídeo foi renderizado, nem promover campos propostos a recursos disponíveis.

## Direção editorial

Para cada beat, determinar o que permanece no quadro, o que entra/sai, o foco da câmera e por que o movimento ajuda a narrativa. Manter o fundo e os elementos existentes quando a intenção é continuidade. Usar PNG com transparência e assets reais; não inventar caminhos. Sincronizar entradas de palavras e personagens com tempos da narração final, após `sourceCuts`. Preservar safe area, leitura e contraste. Movimento não é obrigatório em toda fala.

## JSON proposto

`t` é relativo ao início da cena. Coordenadas `x/y` normalizadas, `scale` adimensional, `rotation` em graus e `opacity` de 0 a 1; easing explícito. Valores omitidos em keyframes herdam o estado anterior. A câmera transforma a composição visual, não a trilha de áudio. Esses detalhes ainda precisam ser confirmados no schema `0.2` implementado. O exemplo do repositório é direção de produto, não teste de compatibilidade.

Se o usuário pedir um JSON executável agora, criar `0.1` e explicar a limitação; se pedir o desenho futuro, entregar um rascunho `0.2` rotulado como não executável.
