# Motion design — Content Lab v0.2

Objetivo: cenas contínuas com fundo persistente, imagens PNG e palavras em camadas, reveladas por uma câmera virtual, sem corte de plano.

## Estado e contrato

- Implementado: JSON `0.2` com fundo estático (cor ou imagem), `scene.camera.keyframes`, elementos `image`/`text` com `id`, `transform` e `keyframes`, além de `sfx` e áudio existente. Consulte `schemas/contentlab.schema.v0.2.json`, `EDIT_PLAN_REFERENCE.md` e `examples/motion-design-proposal.v0.2.json`.
- Ainda não implementado em `0.2`: vídeo/overlay em camadas, caption/kinetic text, grid/cards e edição visual dos keyframes. Para isso, usar `0.1` quando possível.
- Não afirmar que um plano é renderizável sem validação e assets presentes.

## Direção editorial

Para cada beat, determinar o que permanece no quadro, o que entra/sai, o foco da câmera e por que o movimento ajuda a narrativa. Manter o fundo e os elementos existentes quando a intenção é continuidade. Usar PNG com transparência e assets reais; não inventar caminhos. Sincronizar entradas de palavras e personagens com tempos da narração final, após `sourceCuts`. Preservar safe area, leitura e contraste. Movimento não é obrigatório em toda fala.

## JSON executável

`t` é relativo ao início da cena. Coordenadas `x/y` normalizadas, `scale` adimensional, `rotation` em graus e `opacity` de 0 a 1; easing `linear`, `ease_in`, `ease_out` ou `ease_in_out`. Valores omitidos em keyframes herdam o estado anterior. A câmera transforma a composição visual, não a trilha de áudio. `elements[].start/end` são tempos absolutos da timeline final.

Usar `builtin://` para mídia incluída no aplicativo, `project://` para mídia da pasta do vídeo e `background.color` para cores sólidas. A biblioteca interna está vazia até que arquivos autorizados sejam adicionados; nunca inventar que `builtin://backgrounds/papel.png` já existe. Escolher `0.2` apenas para o subconjunto suportado e `0.1` para a edição tradicional.
