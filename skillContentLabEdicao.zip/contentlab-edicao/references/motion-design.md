# Motion design — rota

Leia `references/motion-design-v0.2.md` para o contrato atual e os exemplos. As notas antigas abaixo ficam apenas como contexto e não substituem a referência atual.

Objetivo: cenas contínuas com fundo persistente, imagens PNG e palavras em camadas, reveladas por uma câmera virtual, sem corte de plano.

## Estado e contrato

- Implementado: JSON `0.2` com fundo de cor, imagem ou vídeo, grid 3×3, camadas visuais, câmera, keyframes, presets, captions, cards, música e SFX. Consulte a referência atual antes de gerar JSON.
- A biblioteca padrão ainda não contém mídia distribuída; URIs `builtin://` exigem arquivos reais.
- Não afirmar que um plano é renderizável sem validação e assets presentes.

## Direção editorial

Para cada beat, determinar o que permanece no quadro, o que entra/sai, o foco da câmera e por que o movimento ajuda a narrativa. Manter o fundo e os elementos existentes quando a intenção é continuidade. Usar PNG com transparência e assets reais; não inventar caminhos. Sincronizar entradas de palavras e personagens com tempos da narração final, após `sourceCuts`. Preservar safe area, leitura e contraste. Movimento não é obrigatório em toda fala.

## JSON executável

`t` é relativo ao início da cena. Coordenadas `x/y` normalizadas, `scale` adimensional, `rotation` em graus e `opacity` de 0 a 1; easing `linear`, `ease_in`, `ease_out` ou `ease_in_out`. Valores omitidos em keyframes herdam o estado anterior. A câmera transforma a composição visual, não a trilha de áudio. `elements[].start/end` são tempos absolutos da timeline final.

Usar `builtin://` para mídia incluída no aplicativo, `project://` para mídia da pasta do vídeo e `background.color` para cores sólidas. A biblioteca interna está vazia até que arquivos autorizados sejam adicionados; nunca inventar que `builtin://backgrounds/papel.png` já existe. Escolher a versão conforme o projeto e validar antes de afirmar que o plano é executável.
