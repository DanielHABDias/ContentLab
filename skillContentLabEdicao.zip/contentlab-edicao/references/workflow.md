# Workflow de construção de uma edição no Content Lab

## 1. Fixe a timeline de áudio primeiro
Antes dos visuais, determine:
- narração original;
- `audio.sourceCuts` se houver erros/retakes;
- transcrição que corresponde ao áudio final;
- duração final.

Lembrete: `sourceCuts` são regiões mantidas do áudio original. A timeline visual usa o tempo final limpo.

## 2. Quebre a narração em beats
Um beat é uma unidade de sentido que pede uma decisão visual. Não precisa coincidir com cada frase.

Para cada beat, registrar internamente:
- ideia/fala;
- função: prova, contexto, consequência, comparação, opinião, humor, CTA etc.;
- asset principal;
- necessidade de texto;
- necessidade de layout multi-elemento;
- necessidade de movimento/transição/SFX.

## 3. Escolha a forma visual mais simples que comunica bem
Ordem útil:
1. vídeo/cena direta;
2. imagem direta;
3. card/PNG contextual;
4. comparação/grid;
5. texto editorial;
6. visual simbólico honesto.

Não adicionar múltiplas camadas quando uma cena resolve.

## 4. Use texto com intenção
`text`:
- palavra;
- nome;
- número;
- contraste;
- pergunta;
- frase curta.

`kinetic_text`:
- frase curta e memorável;
- sincronizada à fala;
- poucas palavras enfatizadas.

Não transformar toda a narração em kinetic text.

## 5. Use layout somente quando simultaneidade importa
`left_right`:
- antes/depois;
- personagem A vs B;
- imagem + reação.

`three_columns`:
- 3 personagens/opções.

`character_vs`:
- comparação explícita.

`3x3/custom_grid`:
- composição específica por células.

## 6. Movimento
Para imagem estática, um movimento leve pode ajudar:
- `slow_zoom_in`;
- `slow_zoom_out`;
- `pan`;
- `float_soft` em elementos/personagens.

Não empilhar movimentos só porque existem.

## 7. Transições
Default: `cut`.

Use `fade` ou `blur_left` apenas em virada real, mudança de bloco ou intenção de ritmo.

## 8. Overlay/chroma
Use para:
- CTA;
- partícula;
- greenscreen;
- elemento decorativo funcional.

Defina `z` quando a ordem importa.

## 9. Música e SFX
Música:
- escolha intervalo + preset;
- deixe ducking cuidar da prioridade da voz;
- use `trimDb` só quando necessário.

SFX:
- pontue entrada, impacto ou CTA;
- evite whoosh em toda troca.

## 10. Validação antes do preview
Checar:
- assets;
- presets;
- cenas sem overlap;
- células válidas;
- texto dentro da cena;
- transição suportada;
- transcrição disponível para caption/kinetic;
- música/SFX dentro da duração.

## 11. Preview e correção
Após preview, classifique ajustes:
- timing;
- asset;
- texto;
- motion;
- layout;
- áudio;
- transição;
- excesso/falta de intervenção.

Edite apenas os eventos afetados.
