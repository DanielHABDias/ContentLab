---
name: contentlab-edicao
description: "Cria e revisa edit_plan.json compatível com o Content Lab v0.1 a partir de roteiro, narração/transcrição e assets. Use para planejar a timeline, escolher layouts, textos, captions, animações, transições, overlays/chroma, música e SFX; validar o plano contra as capacidades realmente implementadas; e orientar a construção iterativa da edição até o rough cut."
metadata:
  product: content-lab
  version: "1.0"
  contract: "edit_plan v0.1"
---

# Content Lab — autoria de edição

## Missão
Transformar intenção editorial em um `edit_plan.json` simples, executável e compatível com o Content Lab.

A skill **não renderiza vídeo** e não deve inventar efeitos que o Content Lab ainda não implementa. Ela decide **o que entra, quando entra e qual preset registrado usar**; o Content Lab decide os detalhes de renderização.

Princípio:

**IA/usuário decide O QUE. Content Lab executa COMO.**

---

# 1. Fonte de verdade

A ordem de autoridade é:

1. pedido explícito atual do usuário;
2. `EDIT_PLAN_REFERENCE.md` e schema do repositório atual, quando disponíveis;
3. saída real de `python -m backend.contentlab.cli plugins`, quando disponível;
4. esta skill;
5. referências desta skill.

Se o repositório atual disser que uma capacidade foi adicionada/removida, **o repositório vence**.

Antes de gerar um plano para um projeto real, leia `references/edit-plan-v0.1.md`.

---

# 2. Modos de uso

## Modo A — criar `edit_plan.json`
Receber roteiro/transcrição/assets e produzir um JSON válido para o Content Lab.

## Modo B — guiar a construção da edição
Planejar por beats e explicar quais recursos do Content Lab usar em cada trecho antes de escrever o JSON.

## Modo C — revisar/corrigir um plano existente
Localizar:
- campos não suportados;
- presets inexistentes;
- assets ausentes;
- tempos inválidos;
- overlap de cenas;
- layouts incoerentes;
- texto/caption mal sincronizados;
- excesso de transições/efeitos;
- recursos aceitos pelo schema mas sem efeito real na versão atual.

## Modo D — iterar após preview
Usar feedback do preview para alterar **somente** os trechos necessários, preservando o restante.

---

# 3. Inputs ideais

Para um plano completo, preferir receber:
- roteiro ou texto narrado;
- narração e/ou transcrição com timestamps;
- duração final aproximada;
- lista de assets existentes com caminhos/URIs;
- formato: `youtube_long`, `youtube_short` ou `custom`;
- preferências visuais;
- música/SFX disponíveis, se houver;
- cortes da narração original, se já conhecidos.

Não inventar paths de assets. Se faltar material importante, listar o que falta fora do JSON ou pedir o asset antes de entregar um plano executável.

---

# 4. Workflow de autoria

Leia `references/workflow.md` quando a tarefa envolver um vídeo inteiro.

Resumo:
1. confirmar timeline de áudio;
2. quebrar narração em beats visuais;
3. mapear cada beat para asset/texto/layout;
4. reservar kinetic text para frases realmente importantes;
5. usar caption para fala contínua, não como substituto de toda direção visual;
6. usar layouts multi-elemento quando a ideia exigir comparação simultânea;
7. adicionar overlay/chroma apenas quando necessário;
8. deixar `cut` como default e usar transição especial com função;
9. definir música/SFX sem competir com a voz;
10. validar contrato e assets antes de entregar.

---

# 5. Regra de simplicidade

O JSON descreve intenção, não pixels.

Bom:
```json
{"style":"impact","animation":{"enter":"fade","idle":"none","exit":"cut"}}
```

Ruim:
```json
{"ffmpegFilter":"...","x":917,"y":312,"fontSize":103}
```

Use presets existentes. Não repetir configuração de baixo nível quando um preset resolve.

---

# 6. Tempos e cortes de narração

Regra crítica do Content Lab atual:

- `audio.sourceCuts` = regiões **MANTIDAS** do áudio original;
- `timeline[].start/end` = tempos da timeline FINAL, depois desses cortes;
- a transcrição pode ser remapeada para a narração limpa.

Nunca tratar `sourceCuts` como “trechos que devem ser removidos”.

---

# 7. Capacidade atual — não inventar

No Content Lab v0.1 atual, usar somente capacidades implementadas ou confirmadas pelo runtime.

Principais valores atuais:

- layouts: `fullscreen`, `left_right`, `three_columns`, `character_vs`, `nox`, `custom_grid`, `3x3`;
- transições: `cut`, `fade`, `blur_left`;
- tipos: `video`, `image`, `text`, `kinetic_text`, `caption`, `overlay`, `sfx`;
- text styles: `impact`, `impact_yellow`, `word_pop`, `paper_word`, `versus_big`;
- caption: `anton_karaoke`;
- enter: `cut`, `none`, `fade`, `slide_up`, `pop_in`;
- idle: `none`, `float_soft`, `slow_zoom_in`, `slow_zoom_out`, `pan`, `pulse_soft`;
- exit: `cut`, `none`, `fade`, `fade_out`;
- fit: `cover`, `contain`, `stretch`, `smart_cover`.

Atenções da versão atual:
- `smart_cover` se comporta como `cover`;
- `pop_in` usa entrada com fade;
- `pulse_soft` atualmente não adiciona movimento visual distinto;
- `box.border` é aceito, mas ainda não é desenhado;
- áudio de elementos `video` não entra no mix;
- `project.profile` é metadado nesta versão; não presumir que ele aplica identidade visual sozinho;
- `sources.assetCatalog` é reservado e não alimenta o renderer automaticamente.

---

# 8. Assets e URIs

Visuais, música e SFX:
- `project://...` dentro da pasta do projeto;
- `builtin://...` dentro de `builtin-assets/`.

Narração/transcrição usam caminhos relativos ao projeto.

Use `/` nos URIs mesmo no Windows.

Não usar `../` nem referências fora das raízes válidas.

---

# 9. Texto, kinetic text e caption

## `text`
Use para palavra/frase curta de impacto.

## `kinetic_text`
Use para frase curta sincronizada palavra por palavra. Se `sync: "transcript"`, o texto deve corresponder à fala sempre que possível.

## `caption`
Use para legenda contínua/karaoke a partir de `sources.transcript`.

Não confundir:
- texto editorial = escolha narrativa;
- caption = acompanhamento da fala.

---

# 10. Grid e layouts

Grid 3×3:

```text
1 2 3
4 5 6
7 8 9
```

As `cells` devem formar retângulo contínuo na versão atual.

Exemplos:
- esquerda: `[1,4,7]`;
- centro: `[2,5,8]`;
- direita: `[3,6,9]`;
- topo: `[1,2,3]`;
- dois terços superiores: `[1,2,3,4,5,6]`.

Use `three_columns`, `left_right` ou `character_vs` quando o preset já expressa a intenção. Use `3x3/custom_grid` quando precisar de regiões explícitas.

---

# 11. Cards / box

Para imagem “saltada” da tela, preferir:

```json
"box": "floating_card"
```

Ou override simples:

```json
"box": {
  "preset": "floating_card",
  "padding": 32,
  "radius": 30,
  "shadow": "soft"
}
```

Não depender de `border` para resultado visual na versão atual.

---

# 12. Overlays e chroma

`overlay` é camada visual com chroma key.

Estilos aceitos:
- `green_screen`;
- `green_screen_default`;
- `green_screen_soft`.

Parâmetros implementados em `config`:
- `keyColor`;
- `similarity`;
- `blend`.

Use overrides apenas quando o preset padrão não funcionar bem.

---

# 13. Música, voz e SFX

Presets atuais de música:
- `subtle`;
- `normal`;
- `present`;
- `music_only`.

`trimDb` substitui o ganho do preset.

A voz pode usar normalização, loudness target, true peak, high-pass e ganho.
Música pode usar ducking pela voz.

SFX usam elementos `sfx`, com `at` e `config` opcional.

Não usar SFX/transition só para “encher” a edição.

---

# 14. Regras de qualidade editorial

- default visual pode ser simples;
- corte seco é recurso de primeira classe;
- não trocar imagem só porque passaram X segundos;
- manter uma cena boa enquanto ela continua representando o pensamento;
- usar movimento em imagens quando ajuda a não parecer frame morto;
- evitar repetição próxima quando há alternativa;
- não usar efeito que compete com a informação ou a voz;
- se remover um efeito e nada piora, considere removê-lo.

---

# 15. Entrega

Se o usuário pedir **o arquivo JSON final**, entregar **somente JSON válido**, sem comentários dentro do JSON e sem campos inventados.

Se estiver orientando a edição, pode entregar:
1. mapa visual por beat;
2. decisões/presets;
3. JSON parcial ou final quando solicitado.

Antes de entregar JSON final, conferir:
- `version: "0.1"`;
- `project`, `audio`, `timeline` presentes;
- cenas sem overlap e com IDs únicos;
- todos `start/end` válidos;
- todos assets referenciados existem;
- todos presets pertencem à fase/categoria correta;
- `transitionOut` só usa valor suportado;
- captions têm transcrição;
- `sourceCuts` estão ordenados e representam regiões mantidas;
- duração final está coberta de maneira intencional.

---

# 16. Loop recomendado

**roteiro/transcrição + assets → plano → validar → preview → feedback → corrigir somente o necessário → render final.**

A skill existe para tornar esse loop rápido e previsível, não para transformar cada vídeo em uma configuração gigantesca.
